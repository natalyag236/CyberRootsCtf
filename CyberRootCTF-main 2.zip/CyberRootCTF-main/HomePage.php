<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    echo "<div style='position: absolute; top: 10px; left: 10px;'>Welcome, $username!</div>";
} else {
    echo "<div style='position: absolute; top: 10px; left: 10px;'>You are not logged in!</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cyber Roots CTF</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>

 <!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">CyberRootsCTF.com</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="CTF.html" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Explore</a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="CTF.html">Home Page</a></li>
            <li><a class="dropdown-item" href="CTF.html">CTF Page</a></li>
            <li><a class="dropdown-item" href="Resources Page.html">Resource Page</a></li>
            <li><a class="dropdown-item" href="About us.html">About Us</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
  <!-- Carousel -->
  <section class="carousel-section container mt-5">
    <div id="cyberCarousel" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="Images/Picture7.png" class="d-block w-100" alt="CyberSecurity 1">
        </div>
        <div class="carousel-item">
          <img src="Images/Picture7.png" class="d-block w-100" alt="CyberSecurity 2">
        </div>
        <div class="carousel-item">
          <img src="Images/Picture7.png" class="d-block w-100" alt="CyberSecurity 3">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#cyberCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#cyberCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </section>

  <section class="mission-section text-center py-5">
    <div class="container">
      <h2 class="mb-4">Our Mission</h2>
      <p>At Cyber Roots, we empower individuals and organizations to defend against cyber threats through education, CTF challenges, and a strong community of security professionals.</p>
    </div>
  </section>

  <!-- Card Section -->
  <div class="container mt-5">
    <div class="row text-center">
      <div class="col-md-4">
        <div class="card">
          <img src="Images/Card1.2.png" class="card-img-top" alt="Card 1">
          <div class="card-body">
            <h5 class="card-title">History</h5>
            <p class="card-text">Historically, minorities, including African Americans, have been underrepresented in cybersecurity. Initiatives and projects, like Cyber Roots-CTF, aim to bridge this gap by promoting diverse talent. </p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="Images/card2.jpg" class="card-img-top" alt="Card 2">
          <div class="card-body">
            <h5 class="card-title">Community</h5>
            <p class="card-text">Join our community to learn and share cybersecurity knowledge.</p>
            <a href="Login.html" class="btn btn-primary">Join Now</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="Images/carrd3.jpg" class="card-img-top" alt="Card 3">
          <div class="card-body">
            <h5 class="card-title">Events</h5>
            <p class="card-text">Participate in upcoming events to challenge your skills.</p>
            <a href="https://nrf.go.ke/hackathon/#:~:text=A%20hackathon%20is%20an%20event,focus%20on%20innovation%20and%20creativity." class="btn btn-primary">View Events</a>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Social Media Icons -->
  <footer class="bg-light text-center py-3 mt-5">
    <p>&copy; 2024 Cyber Roots CTF. All rights reserved.</p>
    <a href="https://facebook.com" class="me-2"><img src="Images/Facebook.jpg" alt="Facebook" style="width:24px;"></a>
    <a href="https://instagram.com" class="me-2"><img src="Images/Insta.jpg" alt="Instagram" style="width:24px;"></a>
    
