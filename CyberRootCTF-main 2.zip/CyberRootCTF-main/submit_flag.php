<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "CyberRootsCTF";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Start session and get logged-in username
session_start();
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to submit a flag.']);
    exit;
}
$loggedInUser = $_SESSION['username'];

// Check if flag was submitted
if (!isset($_POST['flag_completed']) || empty($_POST['flag_completed'])) {
    echo json_encode(['success' => false, 'message' => 'Error: No flag submitted.']);
    exit;
}

$flag_completed = $_POST['flag_completed'];
$score = 10; // Score for completing the flag

// Prepare statement to prevent SQL injection
$sql = "INSERT INTO leaderboard (username, flag_completed, score, completion_time)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON DUPLICATE KEY UPDATE score = score + ?, completion_time = CURRENT_TIMESTAMP";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("ssii", $loggedInUser, $flag_completed, $score, $score);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'username' => $loggedInUser]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error executing query: ' . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Error preparing statement: ' . $conn->error]);
}

$conn->close();
?>